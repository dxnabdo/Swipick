import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'

interface Product {
  id: string
  serial: string
  category: string
  categoryCode: string
  brand: string
  brandCode: string
  productType: string
  productCode: string
  price: number
  size: string
  image: string
}

const CATEGORY_MAP: Record<string, string> = {
  'W': 'نساء',
  'M': 'رجال',
  'K': 'أطفال',
  'SH': 'أحذية',
  'BG': 'حقائب',
}

const BRAND_MAP: Record<string, string> = {
  'ZR': 'Zara',
  'NK': 'Nike',
  'AD': 'Adidas',
  'LV': 'Louis Vuitton',
  'GU': 'Gucci',
  'HM': 'H&M',
  'PU': 'Puma',
}

const PRODUCT_MAP: Record<string, string> = {
  'Qa': 'قميص',
  'Ts': 'تيشرت',
  'Ja': 'جاكيت',
  'Ro': 'فستان',
  'Ch': 'حذاء',
  'Pa': 'بنطلون',
  'Ba': 'حقيبة',
  'Ju': 'تنورة',
}

function parseProductSerial(filename: string): Product | null {
  // Format: [Category]-[Brand]-[Product]-[Price]-[Size]-[ID].jpg
  const match = filename.match(/^([A-Z]+)-([A-Z]+)-([A-Za-z]+)-(\d+)-([A-Z0-9]+)-(\d+)\.jpg$/i)
  if (!match) return null
  
  const [, categoryCode, brandCode, productCode, price, size, id] = match
  
  return {
    id,
    serial: filename.replace('.jpg', ''),
    category: CATEGORY_MAP[categoryCode.toUpperCase()] || categoryCode,
    categoryCode: categoryCode.toUpperCase(),
    brand: BRAND_MAP[brandCode.toUpperCase()] || brandCode,
    brandCode: brandCode.toUpperCase(),
    productType: PRODUCT_MAP[productCode] || productCode,
    productCode,
    price: parseInt(price),
    size,
    image: `/products/${filename}`,
  }
}

// Demo products when no real images exist
const DEMO_PRODUCTS: Product[] = [
  {
    id: '0001',
    serial: 'W-ZR-Qa-350-M-0001',
    category: 'نساء',
    categoryCode: 'W',
    brand: 'Zara',
    brandCode: 'ZR',
    productType: 'قميص',
    productCode: 'Qa',
    price: 350,
    size: 'M',
    image: '/products/W-ZR-Qa-350-M-0001.jpg',
  },
  {
    id: '0002',
    serial: 'W-NK-Ts-200-S-0002',
    category: 'نساء',
    categoryCode: 'W',
    brand: 'Nike',
    brandCode: 'NK',
    productType: 'تيشرت',
    productCode: 'Ts',
    price: 200,
    size: 'S',
    image: '/products/W-NK-Ts-200-S-0002.jpg',
  },
  {
    id: '0003',
    serial: 'M-AD-Ja-250-L-0003',
    category: 'رجال',
    categoryCode: 'M',
    brand: 'Adidas',
    brandCode: 'AD',
    productType: 'جاكيت',
    productCode: 'Ja',
    price: 250,
    size: 'L',
    image: '/products/M-AD-Ja-250-L-0003.jpg',
  },
  {
    id: '0004',
    serial: 'K-HM-Ro-80-4Y-0004',
    category: 'أطفال',
    categoryCode: 'K',
    brand: 'H&M',
    brandCode: 'HM',
    productType: 'فستان',
    productCode: 'Ro',
    price: 80,
    size: '4Y',
    image: '/products/K-HM-Ro-80-4Y-0004.jpg',
  },
  {
    id: '0005',
    serial: 'SH-PU-Ch-180-40-0005',
    category: 'أحذية',
    categoryCode: 'SH',
    brand: 'Puma',
    brandCode: 'PU',
    productType: 'حذاء',
    productCode: 'Ch',
    price: 180,
    size: '40',
    image: '/products/SH-PU-Ch-180-40-0005.jpg',
  },
  {
    id: '0006',
    serial: 'BG-LV-Ba-1200-OS-0006',
    category: 'حقائب',
    categoryCode: 'BG',
    brand: 'Louis Vuitton',
    brandCode: 'LV',
    productType: 'حقيبة',
    productCode: 'Ba',
    price: 1200,
    size: 'OS',
    image: '/products/W-LV-Ba-1200-OS-0006.jpg',
  },
  {
    id: '0007',
    serial: 'M-GU-Pa-400-L-0007',
    category: 'رجال',
    categoryCode: 'M',
    brand: 'Gucci',
    brandCode: 'GU',
    productType: 'بنطلون',
    productCode: 'Pa',
    price: 400,
    size: 'L',
    image: '/products/M-GU-Pa-400-L-0007.jpg',
  },
  {
    id: '0008',
    serial: 'W-HM-Ju-120-M-0008',
    category: 'نساء',
    categoryCode: 'W',
    brand: 'H&M',
    brandCode: 'HM',
    productType: 'تنورة',
    productCode: 'Ju',
    price: 120,
    size: 'M',
    image: '/products/W-HM-Ju-120-M-0008.jpg',
  },
  {
    id: '0009',
    serial: 'K-ZR-Qa-60-6Y-0009',
    category: 'أطفال',
    categoryCode: 'K',
    brand: 'Zara',
    brandCode: 'ZR',
    productType: 'قميص',
    productCode: 'Qa',
    price: 60,
    size: '6Y',
    image: '/products/K-ZR-Qa-60-6Y-0009.jpg',
  },
  {
    id: '0010',
    serial: 'SH-NK-Ch-300-41-0010',
    category: 'أحذية',
    categoryCode: 'SH',
    brand: 'Nike',
    brandCode: 'NK',
    productType: 'حذاء',
    productCode: 'Ch',
    price: 300,
    size: '41',
    image: '/products/SH-NK-Ch-300-41-0010.jpg',
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get('category')
  
  try {
    const productsDir = path.join(process.cwd(), 'public', 'products')
    
    let products: Product[] = []
    
    // Check if directory exists and has files
    if (fs.existsSync(productsDir)) {
      const files = fs.readdirSync(productsDir)
      const jpgFiles = files.filter(f => f.endsWith('.jpg') || f.endsWith('.jpeg') || f.endsWith('.png'))
      
      if (jpgFiles.length > 0) {
        products = jpgFiles
          .map(parseProductSerial)
          .filter((p): p is Product => p !== null)
      }
    }
    
    // If no products found, use demo products
    if (!Array.isArray(products) || products.length === 0) {
      products = DEMO_PRODUCTS
    }
    
    // Filter by category if specified
    if (category && category !== 'all') {
      const categoryMap: Record<string, string> = {
        'نساء': 'W',
        'رجال': 'M',
        'أطفال': 'K',
        'أحذية': 'SH',
        'حقائب': 'BG',
      }
      const categoryCode = categoryMap[category] || category.toUpperCase()
      products = products.filter(p => p.categoryCode === categoryCode)
    }
    
    // Always return array
    return NextResponse.json(Array.isArray(products) ? products : [])
  } catch (error) {
    console.error('Error reading products:', error)
    // Return demo products on error
    return NextResponse.json(DEMO_PRODUCTS)
  }
}
